<?php
//易支付配置文件
$alipay_config['partner']= '4334';
$alipay_config['key']= 'E2oe9U88TJ19TO1HhHptTtztKHWw22e6';
$alipay_config['sign_type']= strtoupper('MD5');
$alipay_config['input_charset']= strtolower('utf-8');
$alipay_config['transport']= 'http';
$alipay_config['apiurl']= 'http://pay.sddyun.cn/';
?>