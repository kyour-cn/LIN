<?php
echo cp("http://www.kyour.vip");
