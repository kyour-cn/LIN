<!DOCTYPE html>
<html>
<!--
请尊重作者的劳动成果
作者Q 1270701414
官网  http://www.kyour.vip
        -科佑儿网络
-->
<head>
    <title><?php echo $conf['title']; ?> - 科佑儿网络</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:300,400' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700,900' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="<?php echo $cdn;?>assets/lib/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $cdn;?>assets/lib/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $cdn;?>assets/lib/css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $cdn;?>assets/lib/css/bootstrap-switch.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $cdn;?>assets/lib/css/checkbox3.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $cdn;?>assets/lib/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $cdn;?>assets/lib/css/dataTables.bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $cdn;?>assets/lib/css/select2.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $cdn;?>assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $cdn;?>assets/css/themes/flat-blue.css">
</head>
<body class="flat-blue">
    <div class="app-container">
        <div class="row content-container">