
    <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <a href="#">
                <div class="card red summary-inline">
                    <div class="card-body">
                        <i class="icon fa fa-heartbeat fa-4x"></i>
                        <div class="content">
                            <div class="title">64</div>
                            <div class="sub-title">运行时间</div>
                        </div>
                        <div class="clear-both"></div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <a href="#">
                <div class="card yellow summary-inline">
                    <div class="card-body">
                        <i class="icon fa fa-users fa-4x"></i>
                        <div class="content">
                            <div class="title">70</div>
                            <div class="sub-title">用户数量</div>
                        </div>
                        <div class="clear-both"></div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <a href="#">
                <div class="card green summary-inline">
                    <div class="card-body">
                        <i class="icon fa fa-bar-chart fa-4x"></i>
                        <div class="content">
                            <div class="title">280</div>
                            <div class="sub-title">任务数量</div>
                        </div>
                        <div class="clear-both"></div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <a href="#">
                <div class="card blue summary-inline">
                    <div class="card-body">
                        <i class="icon fa fa-cny fa-4x"></i>
                        <div class="content">
                            <div class="title">643.20</div>
                            <div class="sub-title">交易金额</div>
                        </div>
                        <div class="clear-both"></div>
                    </div>
                </div>
            </a>
        </div>
    </div>
    
    
    <div class="row">
<div class="col-sm-7 col-xs-12">

    
<div class="card">
                                <div class="card-header">
                                    <div class="card-title">
                                        <div class="title">本站公告</div>
                                    </div>
                                </div>
                                <div class="card-body">
                          



            <div class="card">
                <div class="card-body no-padding">
<?php echo $conf['gg'];?>
                </div>
            </div>
</div>
                            </div>
                            
                        </div>

                        <div class="col-sm-5 col-xs-12">
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">
                                    <div class="title">感谢信</div>
                                    </div>
                                </div>
                                <div id="text" class="card-body">
                                    <h5>您好，我们尊敬的客户，给予了我们无比的气力，在您的大力关心与支持下，以及我们全体员工的勤奋努力下，我们凭借优质的服务，良好的信誉，取得了一个又一个的辉煌成绩。<br>&nbsp;&nbsp;&nbsp;&nbsp;饮水思源，我们深知，我们所取得的每一点进步和成功，都离不开您的关注、信任、支持和参与。您的理解和信任是我们进步的强大动力，您的关心和支持是我们成长的不竭源泉。您的每一次参与、每一个建议，都让我们激动不已，促使我们不断奋进。有了您，我们前进的征途才有源源不尽的信心和气力;有了您，我们的事业才能长盛不衰地兴旺和发展。<br>&nbsp;&nbsp;&nbsp;&nbsp;为报答多年来您对我们的支持、信任和帮助，借此岁末年初之际，我们将开展优质服务活动，用真情往返报您，届时您来办理业务，将会让您得到一份惊喜!<br>&nbsp;&nbsp;&nbsp;&nbsp;在今后的岁月里，希看能够继续得到您的关心和大力支持，我们将继续为您提供最真诚的服务。<br>&nbsp;&nbsp;&nbsp;&nbsp;再一次感谢您的帮助和支持，恭祝您身体健康!阖家幸福!事业兴旺!万事如意!
                                    </h5>
                                </div>
                            </div>
                            <br>
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">
                                    <div class="title">热门推荐商品</div>
                                    </div>
                                </div>
                                <div id="text" class="card-body">
    <div class="row">
        <div class="col-md-12">
            <div class="row no-margin no-gap">
                <div class="col-md-3 col-sm-6">
                    <div class="pricing-table dark-blue">
                        <div class="pt-header">
                            <div class="plan-pricing">
                                <div class="pricing">￥4</div>
                                <div class="pricing-type">最低4元起</div>
                            </div>
                        </div>
                        <div class="pt-body">
                            <h4>普通观战</h4>
                            <ul class="plan-detail">
                                <li>dvzsdgbhdfbfd<br>bdsagvwdbvccsxvdbfnfdsd</li>
                            </ul>
                        </div>
                        <div class="pt-footer">
                            <button type="button" class="btn btn-primary">立即购买</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="pricing-table green">
                        <div class="pt-header">
                            <div class="plan-pricing">
                                <div class="pricing">￥25</div>
                                <div class="pricing-type">per month</div>
                            </div>
                        </div>
                        <div class="pt-body">
                            <h4>Standard Plan</h4>
                            <ul class="plan-detail">
                                <li>5 Website</li>
                                <li>500 GB Storage</li>
                            </ul>
                        </div>
                        <div class="pt-footer">
                            <button type="button" class="btn btn-success">立即购买</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="pricing-table  dark-blue">
                        <div class="pt-header">
                            <div class="plan-pricing">
                                <div class="pricing">￥50</div>
                                <div class="pricing-type">per month</div>
                            </div>
                        </div>
                        <div class="pt-body">
                            <h4>Advanced Plan</h4>
                            <ul class="plan-detail">
                                <li>10 Website</li>
                                <li>1 TB Storage</li>
                            </ul>
                        </div>
                        <div class="pt-footer">
                            <button type="button" class="btn btn-primary">立即购买</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="pricing-table green">
                        <div class="pt-header">
                            <div class="plan-pricing">
                                <div class="pricing">￥100</div>
                                <div class="pricing-type">per month</div>
                            </div>
                        </div>
                        <div class="pt-body">
                            <h4>Unlimited Plan</h4>
                            <ul class="plan-detail">
                                <li>Unlimited Website</li>
                                <li>Unlimited Storage</li>
                            </ul>
                        </div>
                        <div class="pt-footer">
                            <button type="button" class="btn btn-success">立即购买</button>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
                                </div>
                            </div>
                        </div>

                    </div>




